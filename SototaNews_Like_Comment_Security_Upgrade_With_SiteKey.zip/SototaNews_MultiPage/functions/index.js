const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const crypto = require("crypto");

initializeApp();
const db = getDatabase();

function fail(code, message) { throw new HttpsError(code, message); }
function validateTarget(data) {
  const postId = String(data?.postId || "").trim();
  const postType = String(data?.postType || "");
  if (!postId || postId.length > 128 || !/^[A-Za-z0-9_-]+$/.test(postId)) fail("invalid-argument", "Invalid post ID.");
  if (!["news", "blog"].includes(postType)) fail("invalid-argument", "Invalid post type.");
  return { postId, postType, table: postType === "blog" ? "blog_posts" : "news_posts" };
}
function requireVisitor(request) {
  if (!request.auth) fail("unauthenticated", "Visitor authentication required.");
  const uid = request.auth.uid;
  const ip = String(request.rawRequest?.ip || "unknown");
  const ipHash = crypto.createHash("sha256").update(ip + (process.env.IP_HASH_SALT || "sotota-news-ip-v1")).digest("hex");
  const uidHash = crypto.createHash("sha256").update(uid).digest("hex");
  return { uidHash, ipHash };
}
function key(value) { return Buffer.from(value, "utf8").toString("base64url"); }

async function locatePost(table, postId) {
  const ref = db.ref(table);
  const snap = await ref.get();
  const posts = snap.val();
  if (!Array.isArray(posts)) fail("not-found", "Post not found.");
  const index = posts.findIndex(p => p && String(p.id) === postId);
  if (index < 0) fail("not-found", "Post not found.");
  return { ref, index };
}

exports.getInteractionStatus = onCall({ enforceAppCheck: true, maxInstances: 20 }, async (request) => {
  const { uidHash } = requireVisitor(request);
  const { postId, postType } = validateTarget(request.data);
  const ref = db.ref(`public_interactions/${postType}_${key(postId)}`);
  const snap = await ref.get();
  const data = snap.val() || {};
  return {
    liked: !!(data.likesByUid && data.likesByUid[uidHash]),
    commented: !!(data.commentsByUid && data.commentsByUid[uidHash])
  };
});

exports.addLike = onCall({ enforceAppCheck: true, maxInstances: 30 }, async (request) => {
  const { uidHash, ipHash } = requireVisitor(request);
  const { postId, postType, table } = validateTarget(request.data);
  const { ref: postsRef, index } = await locatePost(table, postId);
  const interactionRef = db.ref(`public_interactions/${postType}_${key(postId)}`);
  const claim = await interactionRef.transaction(current => {
    current = current || {};
    current.likesByUid = current.likesByUid || {};
    current.likesByIp = current.likesByIp || {};
    if (current.likesByUid[uidHash] || current.likesByIp[ipHash]) return;
    current.likesByUid[uidHash] = true;
    current.likesByIp[ipHash] = true;
    current.likeCount = Object.keys(current.likesByUid).length;
    return current;
  });
  if (!claim.committed) fail("already-exists", "This visitor or network has already liked this post.");
  const count = Number(claim.snapshot.val()?.likeCount || 0);
  const postUpdate = await postsRef.child(String(index)).transaction(post => {
    if (!post || String(post.id) !== postId) return;
    post.likes = count;
    return post;
  });
  if (!postUpdate.committed) fail("not-found", "Post changed while processing the like.");
  return { likeCount: count };
});

exports.submitComment = onCall({ enforceAppCheck: true, maxInstances: 20 }, async (request) => {
  const { uidHash, ipHash } = requireVisitor(request);
  const { postId, postType, table } = validateTarget(request.data);
  const name = String(request.data?.name || "").trim();
  const text = String(request.data?.text || "").trim();
  if (!name || name.length > 50) fail("invalid-argument", "Name must be 1-50 characters.");
  if (!text || text.length > 2000) fail("invalid-argument", "Comment must be 1-2000 characters.");
  // Treat input as plain text. Reject markup/code-like payloads; browser output is textContent only.
  if (/[<>]|javascript\s*:|data\s*:\s*text\/html|on[a-z]+\s*=|<\s*script/i.test(name + "\n" + text)) {
    fail("invalid-argument", "HTML and executable code are not allowed.");
  }
  const now = Date.now();
  const { ref: postsRef, index } = await locatePost(table, postId);
  const interactionRef = db.ref(`public_interactions/${postType}_${key(postId)}`);
  const lastRef = db.ref(`public_interaction_rate_limits/${key(uidHash)}`);
  const ipLastRef = db.ref(`public_interaction_ip_limits/${ipHash}`);
  const uidRate = await lastRef.transaction(last => {
    if (last && now - Number(last) < 60000) return;
    return now;
  });
  if (!uidRate.committed) fail("resource-exhausted", "Please wait at least 60 seconds before commenting again.");
  const ipRate = await ipLastRef.transaction(last => {
    if (last && now - Number(last) < 60000) return;
    return now;
  });
  if (!ipRate.committed) fail("resource-exhausted", "Please wait at least 60 seconds before commenting again.");
  const claim = await interactionRef.transaction(current => {
    current = current || {};
    current.commentsByUid = current.commentsByUid || {};
    current.commentsByIp = current.commentsByIp || {};
    if (current.commentsByUid[uidHash] || current.commentsByIp[ipHash]) return;
    current.commentsByUid[uidHash] = true;
    current.commentsByIp[ipHash] = true;
    return current;
  });
  if (!claim.committed) fail("already-exists", "Only one comment per visitor and post is allowed.");
  const comment = { name, text, timestamp: now };
  const updated = await postsRef.child(String(index)).transaction(post => {
    if (!post || String(post.id) !== postId) return;
    post.comments = Array.isArray(post.comments) ? post.comments : [];
    post.comments.push(comment);
    return post;
  });
  if (!updated.committed) fail("not-found", "Post changed while processing the comment.");
  return { comments: updated.snapshot.val().comments };
});
