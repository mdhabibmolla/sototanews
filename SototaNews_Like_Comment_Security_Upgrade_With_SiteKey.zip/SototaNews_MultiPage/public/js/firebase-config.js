// Firebase Web SDK config. Public client configuration only.
window.SOTOTA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDK-g0U6176dyrKi2lY9brEukWHoVO0_Oo",
  databaseURL: "https://sototanews1-default-rtdb.firebaseio.com",
  projectId: "sototanews1"
};
// REQUIRED: Set your reCAPTCHA v3 site key from Firebase App Check.
// Leave empty until configured; public Like/Comment actions fail closed without App Check.
window.SOTOTA_APP_CHECK_SITE_KEY = "6LcGHRAuAAAAAO3mMEs3iqJ-2Op6uElhbtSftzxO";
window.SOTOTA_FUNCTIONS_REGION = "us-central1";
