<?php
require __DIR__.'/seo-lib.php';
header('Content-Type: application/xml; charset=UTF-8');
header('Cache-Control: public, max-age=300');
$news=rows(db_get('news_posts')); $blogs=rows(db_get('blog_posts'));
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
$static=['','index.html','categories.html','about.html','contact.html','privacy-policy.html','editorial-policy.html','correction-policy.html'];
foreach($static as $p) echo '<url><loc>'.h(absolute_url($p)).'</loc></url>';
foreach(array_merge($news,$blogs) as $p){$id=(string)($p['id']??''); if(!$id||empty($p['title']))continue; echo '<url><loc>'.h(article_canonical($id)).'</loc><lastmod>'.h(date('c',max(1,(int)(($p['updatedAt']??$p['timestamp']??time()*1000)/1000)))).'</lastmod></url>';}
echo '</urlset>';
