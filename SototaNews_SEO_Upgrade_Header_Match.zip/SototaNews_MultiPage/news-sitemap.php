<?php
require __DIR__.'/seo-lib.php';
header('Content-Type: application/xml; charset=UTF-8'); header('Cache-Control: public, max-age=300');
$posts=rows(db_get('news_posts')); $cut=time()*1000-2*86400000;
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">';
$brandData=db_get('branding_settings') ?: []; $publicationName=$brandData['title'] ?? 'সততা নিউজ';
foreach($posts as $p){$ts=(int)($p['timestamp']??0); if(empty($p['id']) || empty($p['title'])) continue; if($ts && $ts<$cut)continue; $url=article_canonical((string)$p['id']); $date=$ts?date('c',(int)($ts>9999999999?$ts/1000:$ts)):date('c'); echo '<url><loc>'.h($url).'</loc><news:news><news:publication><news:name>'.h($publicationName).'</news:name><news:language>bn</news:language></news:publication><news:publication_date>'.h($date).'</news:publication_date><news:title>'.h($p['title']??'').'</news:title></news:news></url>'; }
echo '</urlset>';
