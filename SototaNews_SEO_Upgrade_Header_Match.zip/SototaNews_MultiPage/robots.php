<?php
require __DIR__.'/seo-lib.php';
header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: public, max-age=3600');
echo "User-agent: *\nAllow: /\nDisallow: /admin.html\nDisallow: /legacy/\nDisallow: /partials/\nDisallow: /seo-lib.php\n\n";
echo 'Sitemap: '.absolute_url('sitemap.php')."\n";
echo 'Sitemap: '.absolute_url('news-sitemap.php')."\n";
