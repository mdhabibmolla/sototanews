<?php
// Sotota News: shared server-side SEO helpers. No Firebase Admin secret is used.
const SOTOTA_DB_URL = 'https://sototanews1-default-rtdb.firebaseio.com';
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function db_get(string $path) {
  $url = SOTOTA_DB_URL . '/' . trim($path, '/') . '.json';
  $raw = false;
  if (ini_get('allow_url_fopen')) {
    $ctx = stream_context_create(['http' => ['timeout' => 8, 'ignore_errors' => true, 'header' => "Accept: application/json\r\n"]]);
    $raw = @file_get_contents($url, false, $ctx);
  }
  if ($raw === false && function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 8, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
    $raw = curl_exec($ch); curl_close($ch);
  }
  if ($raw === false || $raw === null) return null;
  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}
function rows($data): array {
  if (!is_array($data)) return [];
  $out=[];
  foreach ($data as $k=>$v) if (is_array($v)) { if (!isset($v['id'])) $v['id']=(string)$k; $out[]=$v; }
  return $out;
}
function post_by_id(string $id): array {
  $blog = str_starts_with($id, 'b_');
  $list = rows(db_get($blog ? 'blog_posts' : 'news_posts'));
  foreach ($list as $p) if ((string)($p['id'] ?? '') === $id) return [$p, $blog];
  return [null, $blog];
}
function absolute_url(string $path=''): string {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
  $scheme = $https ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  return $scheme . '://' . $host . '/' . ltrim($path, '/');
}
function clean_text($html): string { return trim(preg_replace('/\\s+/u', ' ', html_entity_decode(strip_tags((string)$html), ENT_QUOTES | ENT_HTML5, 'UTF-8'))); }
function date_iso($ms): string { $n=is_numeric($ms)?(int)$ms:time()*1000; if($n>9999999999)$n=(int)floor($n/1000); return gmdate('c', (int)$n); }
function safe_article_html($html): string {
  $allowed='<p><br><b><strong><i><em><u><ul><ol><li><h2><h3><h4><blockquote><a><img>';
  $html=strip_tags((string)$html,$allowed);
  // Strip event handlers and javascript/data URLs from retained markup.
  $html=preg_replace("/\\s+on[a-z]+\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)/i", '', $html);
  $html=preg_replace("/(href|src)\\s*=\\s*([\"'])\\s*(javascript:|data:)[^\"']*\\2/i", '$1="#"', $html);
  return $html;
}
function article_canonical(string $id): string { return absolute_url('article.php?news=' . rawurlencode($id)); }
