# সততা নিউজ — SEO Upgrade (Namecheap PHP Hosting)

এই আপডেটটি মূল Modular Starter-এর ওপর তৈরি। বিদ্যমান Home, Category, Admin UI, Firebase client logic, Likes, Comments, Views, Adsterra settings, Branding, Font settings এবং PWA ফাইল রাখা হয়েছে। Firebase Database Rules বা Admin Login flow পরিবর্তন করা হয়নি।

## নতুন SEO ফিচার
- `article.php?news=POST_ID`: Firebase Realtime Database থেকে Article সার্ভারেই পড়ে পূর্ণ HTML, H1, Article text, meta description, canonical, Open Graph, Twitter Card এবং JSON-LD `NewsArticle`/`BlogPosting` দেয়।
- `sitemap.php`: News ও Blog-এর dynamic XML sitemap।
- `news-sitemap.php`: গত ৪৮ ঘণ্টার News-এর Google News Sitemap।
- `robots.php`: লাইভ Domain অনুসারে Sitemap URL তৈরি করে; `.htaccess`-এ `/robots.txt` হিসেবে serve হয়।
- Article share/click URL এখন `article.php?news=...`; পুরোনো `article.html?news=...` link এখনও Firebase JS দিয়ে কাজ করবে, তবে SEO-র জন্য নতুন `article.php` link ব্যবহার করুন।
- Admin page-এ `noindex,nofollow`; service-worker cache version বাড়ানো হয়েছে।
- About, Contact, Privacy, Editorial ও Correction Policy-এর প্রাথমিক পেজ যোগ হয়েছে। প্রকাশের আগে Contact ও Privacy text নিজের বাস্তব তথ্য অনুযায়ী সম্পাদনা করুন।

## Namecheap Stellar Plus Trial-এ Upload
1. ZIP extract করুন। ভিতরের `SototaNews_MultiPage` ফোল্ডারের সব ফাইল `public_html`-এ upload করুন (ফোল্ডারটি নিজে `public_html/SototaNews_MultiPage` হিসেবে নয়, যদি Root Domain-এ চালাতে চান)।
2. cPanel → Select PHP Version থেকে PHP 8.1 বা নতুন সংস্করণ নির্বাচন করুন। `allow_url_fopen` সক্রিয় থাকা দরকার, কারণ PHP Firebase Realtime Database-এর public REST endpoint পড়ে। যদি Host সেটি বন্ধ রাখে, `seo-lib.php`-তে cURL fallback যোগ করতে হবে।
3. `.htaccess` upload হয়েছে কি না নিশ্চিত করুন। Apache `mod_rewrite` ও `mod_headers` সক্রিয় থাকা দরকার।
4. HTTPS/SSL সক্রিয় করুন। তারপর `https://YOUR-DOMAIN/article.php?news=একটি-বাস্তব-POST_ID` পরীক্ষা করুন।
5. `https://YOUR-DOMAIN/sitemap.php`, `/news-sitemap.php` ও `/robots.txt` খুলে XML/robots output পরীক্ষা করুন।
6. Firebase Authentication → Settings → Authorized domains-এ তোমার Domain যোগ করুন।
7. Google Search Console-এ Domain Property verify করে `sitemap.php` submit করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা ও সতর্কতা
- এই পরিবেশে তোমার Firebase live data-তে সংযোগ করে পরীক্ষা করা যায়নি। তাই `news_posts`/`blog_posts`-এর ডেটা public Realtime Database REST read থেকে আসতে হবে। তোমার দেওয়া Rules-এ `.read: true` আছে, তাই server-side public article fetch সম্ভব; Rules পরিবর্তন করা হয়নি।
- Root `.read: true` থাকলে Realtime Database-এর সব path-ই public read হতে পারে। Database-এ private user data, secrets বা সংবেদনশীল Admin তথ্য রাখবে না। ভবিষ্যতে Rules path অনুযায়ী আলাদা করতে হবে, তবে আগে অ্যাপের সব interaction পরীক্ষা করতে হবে।
- `.write: auth != null` যেকোনো authenticated account-কে write করতে দেয়; এটি Admin-only নয়। তুমি Admin Login পরিবর্তন না করতে বলেছ বলে এই প্যাকেজে Rules স্পর্শ করা হয়নি।
- PHP server Firebase REST endpoint-এ request করতে না পারলে Article SSR ও Sitemap empty/error হতে পারে। তখন cPanel PHP extension/network setting পরীক্ষা করতে হবে।
- Google Index/Ranking নিশ্চিত করা যায় না। Sitemap ও structured data discovery-তে সাহায্য করে, ranking নির্ভর করে original content, authority, technical quality ও search intent-এর ওপর।
- Google News Sitemap-এ সাম্প্রতিক News রাখা হয়েছে; Blog entries এতে অন্তর্ভুক্ত নয়। সাধারণ sitemap-এ News এবং Blog দুটোই আছে।
- Article content যদি untrusted HTML হয়, `seo-lib.php`-এর sanitizer basic allowlist ব্যবহার করে। Rich formatting-এর প্রয়োজন হলে নিরাপদ sanitizer আরও শক্ত করতে হবে।

## দ্রুত পরীক্ষা
- Home: `/index.html`
- Article SEO: `/article.php?news=POST_ID`
- Sitemap: `/sitemap.php`
- News sitemap: `/news-sitemap.php`
- Robots: `/robots.txt`
- Admin: `/admin.html` (Google-এ index নয়)

## GitHub-এ ভবিষ্যৎ Shift
এই প্যাকেজের `article.php`, `seo-lib.php`, `sitemap.php`, `news-sitemap.php` PHP runtime চায়; GitHub Pages-এ PHP চলে না। ভবিষ্যতে GitHub-এ গেলে একই Article HTML ও Sitemap Firebase Cloud Functions/অন্য serverless renderer দিয়ে generate করতে হবে। Static Home/CSS/JS GitHub Pages-এ রাখা যাবে, কিন্তু PHP endpoint সরাসরি নয়।
